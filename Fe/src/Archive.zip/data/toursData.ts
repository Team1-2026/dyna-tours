export interface ItineraryItem {
  day: number;
  title: string;
  description: string;
}

export interface Tour {
  id: string;
  title: string;
  destination: string;
  category: 'Nature' | 'Culture' | 'Adventure' | 'Leisure' | 'History';
  price: number;
  duration: string;
  durationDays: number;
  rating: number;
  reviewsCount: number;
  description: string;
  highlights: string[];
  itinerary: ItineraryItem[];
  inclusions: string[];
  exclusions: string[];
  image: string;
  gallery: string[];
  featured?: boolean;
}

export const toursData: Tour[] = [
  {
    id: "swiss-alps-adventure",
    title: "Swiss Alps Peaks & Valleys Tour",
    destination: "Zermatt & Interlaken, Switzerland",
    category: "Adventure",
    price: 1899,
    duration: "7 Days / 6 Nights",
    durationDays: 7,
    rating: 4.9,
    reviewsCount: 142,
    description: "Embark on an alpine journey of a lifetime. Experience the majestic Matterhorn, ride the scenic Glacier Express, and hike through the pristine green valleys of Lauterbrunnen. This adventure combines premium comfort with the thrill of Europe's highest peaks.",
    highlights: [
      "Panoramic train ride on the world-famous Glacier Express",
      "Guided hike in the car-free village of Zermatt with Matterhorn views",
      "Cable car ride to the Top of Europe (Jungfraujoch)",
      "Traditional Swiss fondue tasting dinner in Interlaken"
    ],
    itinerary: [
      {
        day: 1,
        title: "Arrival in Zurich & Transfer to Zermatt",
        description: "Welcome to Switzerland! Arrive in Zurich and take the scenic train ride south to Zermatt. Check into your premium alpine lodge and spend the evening exploring this beautiful car-free mountain village."
      },
      {
        day: 2,
        title: "Gornergrat Cogwheel Railway & Matterhorn Views",
        description: "Ride Europe's highest open-air cogwheel railway up to Gornergrat (3,089m). Enjoy breathtaking, panoramic views of the Matterhorn and surrounding glaciers. Embark on a gentle guided hike back down to Riffelsee."
      },
      {
        day: 3,
        title: "Glacier Express to Andermatt & Interlaken",
        description: "Board the Glacier Express, 'the slowest express train in the world.' Sit back in your panoramic coach as you cross deep valleys, climb mountain passes, and travel through the heart of the Swiss Alps before transferring to Interlaken."
      },
      {
        day: 4,
        title: "Jungfraujoch - Top of Europe Experience",
        description: "Ascend to Jungfraujoch, the highest railway station in Europe at 3,454 meters. Explore the Ice Palace, step out onto the Sphinx Observation Terrace for views of the Aletsch Glacier, and play in the snow."
      },
      {
        day: 5,
        title: "Lauterbrunnen Valley & Trümmelbach Falls",
        description: "Discover the valley of 72 waterfalls. Walk through Lauterbrunnen and visit the subterranean Trümmelbach Falls, where glacier meltwater thunders through the mountain. Spend the afternoon canoeing on Lake Brienz."
      },
      {
        day: 6,
        title: "Leisure Day in Interlaken & Farewell Dinner",
        description: "Enjoy a day at your own pace. Opt for paragliding over Interlaken, shopping, or taking a cruise on Lake Thun. In the evening, gather for a traditional Swiss fondue and raclette farewell dinner."
      },
      {
        day: 7,
        title: "Departure from Zurich",
        description: "Transfer back to Zurich airport by train for your departure flight, taking home unforgettable memories of the Swiss peaks."
      }
    ],
    inclusions: [
      "6 nights in boutique 4-star alpine hotels",
      "Daily buffet breakfasts and 3 premium dinners",
      "1st class Swiss Travel Pass for all trains and buses",
      "All cable cars and mountain railways tickets mentioned",
      "Certified local mountain guides"
    ],
    exclusions: [
      "International flights to/from Zurich",
      "Lunch and dinner meals not specified",
      "Travel insurance (highly recommended)",
      "Optional adventure activities like paragliding"
    ],
    image: "/images/swiss_alps.png",
    gallery: [
      "/images/swiss_alps.png"
    ],
    featured: true
  },
  {
    id: "kyoto-cultural-explorer",
    title: "Kyoto Zen Gardens & Shrine Heritage",
    destination: "Kyoto, Japan",
    category: "Culture",
    price: 1499,
    duration: "5 Days / 4 Nights",
    durationDays: 5,
    rating: 4.8,
    reviewsCount: 96,
    description: "Immerse yourself in the ancient traditions of Japan's cultural capital. From the shimmering golden walls of Kinkaku-ji to the thousands of vermilion gates at Fushimi Inari, this curated experience brings you closer to Zen philosophy, tea ceremonies, and artisan history.",
    highlights: [
      "Exclusive private tea ceremony hosted by a certified Tea Master",
      "Early morning walk through the Arashiyama Bamboo Grove",
      "Guided sunset stroll through the historic Gion district",
      "Stay in a traditional Japanese Ryokan with onsen bath experience"
    ],
    itinerary: [
      {
        day: 1,
        title: "Arrival in Kyoto & Gion Sunset Walk",
        description: "Arrive in Kyoto via Shinkansen (bullet train) from Tokyo. Check into your premium ryokan. In the evening, enjoy a guided stroll through Gion, Kyoto's famous geisha district, as the lanterns light up."
      },
      {
        day: 2,
        title: "Golden Pavilion & Ryoan-ji Rock Garden",
        description: "Visit Kinkaku-ji (Golden Pavilion), reflecting beautifully over its pond. Next, head to Ryoan-ji Temple to contemplate Japan's most famous Zen rock garden. Have a traditional Buddhist vegetarian lunch (Shojin Ryori)."
      },
      {
        day: 3,
        title: "Fushimi Inari Gates & Kiyomizu-dera Temple",
        description: "Rise early to hike through the thousands of vermilion torii gates at Fushimi Inari Shrine. In the afternoon, visit the wooden stage of Kiyomizu-dera for stunning panoramic views of Kyoto."
      },
      {
        day: 4,
        title: "Arashiyama Bamboo Forest & Tea Ceremony",
        description: "Walk the towering bamboo paths of Arashiyama. Visit Tenryu-ji Temple and its scenic gardens. In the afternoon, participate in a private, meditative Matcha tea ceremony in a historic wooden tea house."
      },
      {
        day: 5,
        title: "Nishiki Market & Departure",
        description: "Explore the narrow streets of Nishiki Market, tasting local delicacies and picking up handmade souvenirs. Transfer to Kansai Airport or Kyoto Station for your onwards journey."
      }
    ],
    inclusions: [
      "3 nights in a premium boutique hotel and 1 night in a traditional luxury Ryokan",
      "Daily breakfasts and traditional Kaiseki multi-course dinner",
      "Private English-speaking local cultural guides",
      "All entrance fees to temples, gardens, and shrines",
      "Private tea ceremony experience"
    ],
    exclusions: [
      "Flights to Japan and airport taxes",
      "Shinkansen tickets to/from Kyoto (can be booked via JR Pass)",
      "Personal items and gratuities"
    ],
    image: "/images/kyoto_japan.png",
    gallery: [
      "/images/kyoto_japan.png"
    ],
    featured: true
  },
  {
    id: "amalfi-coast-escape",
    title: "Amalfi Coast & Capri Cliffside Escape",
    destination: "Positano & Capri, Italy",
    category: "Leisure",
    price: 2199,
    duration: "6 Days / 5 Nights",
    durationDays: 6,
    rating: 4.95,
    reviewsCount: 184,
    description: "Indulge in the ultimate Mediterranean getaway. Cruise along the dramatic coastline, explore the colorful cliffside villages of Positano and Ravello, swim in the Blue Grotto of Capri, and savor authentic regional cuisine with views of the azure sea.",
    highlights: [
      "Private boat excursion around the Isle of Capri and the Blue Grotto",
      "Exclusive lemon farm tour and limoncello tasting in Sorrento",
      "Scenic drive along the cliffside roads with local Italian drivers",
      "Cooking class with a local chef overlooking the Mediterranean"
    ],
    itinerary: [
      {
        day: 1,
        title: "Arrival in Sorrento & Welcome Aperitivo",
        description: "Arrive in Naples and transfer to Sorrento. Check into your cliffside hotel. Join the group for a welcome aperitivo on the terrace, watching the sunset over Mount Vesuvius."
      },
      {
        day: 2,
        title: "Positano Exploration & Scenic Amalfi Drive",
        description: "Drive along the winding coastal roads to Positano. Take a guided walk through its narrow, flower-draped streets down to the beach. Continue to the town of Amalfi to visit its medieval cathedral."
      },
      {
        day: 3,
        title: "Capri Yacht Cruise & Blue Grotto Swim",
        description: "Board a private yacht for a full-day cruise to Capri. Sail past the Faraglioni rock formations, visit the glowing Blue Grotto, and enjoy free time to shop and dine in Capri town."
      },
      {
        day: 4,
        title: "Ravello Gardens & Cooking Masterclass",
        description: "Head high into the hills to Ravello. Explore the panoramic gardens of Villa Rufolo. In the afternoon, learn to make fresh pasta and tiramisu at a family-run cliffside estate, followed by dinner."
      },
      {
        day: 5,
        title: "Pompeii Guided Tour & Limoncello Tasting",
        description: "Take a morning excursion to the archaeological site of Pompeii, frozen in time by Mt. Vesuvius. Return to Sorrento for a farewell dinner at a lemon grove farm with limoncello tasting."
      },
      {
        day: 6,
        title: "Departure from Naples",
        description: "Enjoy a final breakfast overlooking the bay before transferring back to Naples airport for your return flight home."
      }
    ],
    inclusions: [
      "5 nights in 4-star and 5-star cliffside boutique hotels",
      "Daily buffet breakfasts, 2 dinners, and 1 lunch",
      "Private yacht cruise to Capri with drinks & snacks",
      "Private Mercedes minivan transfers for all sightseeing",
      "Entrance tickets and expert guides for Pompeii"
    ],
    exclusions: [
      "Flights to Naples",
      "City tourist taxes (paid locally)",
      "Optional tips for drivers and captains"
    ],
    image: "/images/amalfi_coast.png",
    gallery: [
      "/images/amalfi_coast.png"
    ],
    featured: true
  },
  {
    id: "serengeti-wildlife-safari",
    title: "Serengeti & Ngorongoro Big Five Safari",
    destination: "Serengeti National Park, Tanzania",
    category: "Nature",
    price: 2499,
    duration: "6 Days / 5 Nights",
    durationDays: 6,
    rating: 4.88,
    reviewsCount: 74,
    description: "Witness the greatest wildlife spectacle on Earth. Traverse the endless plains of the Serengeti, descend into the massive Ngorongoro Crater, spot lions, leopards, elephants, rhinos, and buffaloes, and stay in luxurious eco-tented lodges under the African stars.",
    highlights: [
      "Daily game drives in customized open-roof 4x4 Land Cruisers",
      "Full-day expedition in the UNESCO-listed Ngorongoro Crater",
      "Stay in premium luxury tented camps with roaring campfires",
      "Authentic Maasai cultural village visit and dance ritual"
    ],
    itinerary: [
      {
        day: 1,
        title: "Arusha to Lake Manyara National Park",
        description: "Meet your guide in Arusha and drive to Lake Manyara. Famous for tree-climbing lions and flocks of pink flamingos, enjoy your first afternoon game drive before settling into your lodge."
      },
      {
        day: 2,
        title: "Ngorongoro Crater Exploration",
        description: "Descend 600 meters into the Ngorongoro Crater, a volcanic caldera hosting over 30,000 animals. Spend the day spotting black rhinos, prides of lions, and elephants. Picnic lunch inside the crater."
      },
      {
        day: 3,
        title: "Journey to the Serengeti Plains",
        description: "Drive into the endless plains of the Serengeti, looking out for wildlife along the way. Arrive at your luxury safari camp in time for sunset drinks around the boma fire."
      },
      {
        day: 4,
        title: "Full Day Serengeti Game Drives",
        description: "Embark on morning and afternoon game drives. Seek out cheetahs hunting, leopards lounging in acacia trees, and watch the herds of wildebeest and zebras migrating across the golden savannah."
      },
      {
        day: 5,
        title: "Sunrise Balloon Safari & Maasai Culture",
        description: "Optionally drift over the Serengeti in a hot air balloon at sunrise. Later, visit a Maasai boma (village) to learn about their nomadic lifestyle, beadwork, and traditional jumping dances."
      },
      {
        day: 6,
        title: "Return to Arusha & Departure",
        description: "Take a short morning game drive as you leave the park. Fly or drive back to Arusha for your outbound flight or Zanzibar beach extension."
      }
    ],
    inclusions: [
      "5 nights in luxury safari lodges and tented camps",
      "All meals (Breakfast, Lunch, Dinner) throughout the safari",
      "Private 4x4 safari vehicle with professional driver-guide",
      "All national park fees, crater service fees, and conservation fees",
      "Bottled water and binoculars provided in the safari vehicle"
    ],
    exclusions: [
      "International flights to/from Kilimanjaro (JRO)",
      "Optional Hot Air Balloon Safari (₹550 per person)",
      "Tanzania tourist visa",
      "Tips for safari guide (approx. ₹20/day recommended)"
    ],
    image: "/images/serengeti_safari.png",
    gallery: [
      "/images/serengeti_safari.png"
    ],
    featured: true
  },
  {
    id: "romance-in-paris",
    title: "Paris Art, Romance & Gastronomy Tour",
    destination: "Paris, France",
    category: "History",
    price: 1299,
    duration: "5 Days / 4 Nights",
    durationDays: 5,
    rating: 4.75,
    reviewsCount: 112,
    description: "Fall in love with the City of Light. Walk through the cobblestone streets of Montmartre, skip the lines at the Louvre and Musée d'Orsay, sail down the Seine River on a dinner cruise, and discover the secrets of French baking in a private pastry kitchen.",
    highlights: [
      "VIP skip-the-line access to the Louvre Museum and Eiffel Tower",
      "Seine River gourmet dinner cruise with live violin music",
      "Private French macaron baking class in a Parisian kitchen",
      "Chauffeur-driven vintage car tour of Paris landmarks"
    ],
    itinerary: [
      {
        day: 1,
        title: "Arrival in Paris & Seine Dinner Cruise",
        description: "Arrive in Paris and check into your boutique hotel in Saint-Germain-des-Prés. In the evening, embark on a luxury dinner cruise on the Seine River, gliding past the illuminated Notre-Dame and Eiffel Tower."
      },
      {
        day: 2,
        title: "Louvre Masterpieces & Montmartre Walk",
        description: "Enjoy a VIP guided tour of the Louvre, seeing the Mona Lisa and Venus de Milo. In the afternoon, explore the artistic hill of Montmartre, visiting the Sacré-Cœur and local artists at Place du Tertre."
      },
      {
        day: 3,
        title: "Eiffel Tower Summit & Macaron Class",
        description: "Ascend to the summit of the Eiffel Tower for panoramic city views. In the afternoon, join an expert pastry chef to learn the delicate art of making French macarons, enjoying them with champagne."
      },
      {
        day: 4,
        title: "Palace of Versailles Excursion",
        description: "Take a short train trip to the Palace of Versailles. Guided tour of the Hall of Mirrors and the King's State Apartments, followed by a leisurely stroll through the fountain gardens."
      },
      {
        day: 5,
        title: "Marais Boutiques & Departure",
        description: "Spend your final morning shopping and cafe-hopping in the trendy Le Marais district. Pick up gourmet chocolates and baguettes before heading to the airport."
      }
    ],
    inclusions: [
      "4 nights in a 4-star boutique hotel in central Paris",
      "Daily French breakfasts and 1 gourmet dinner cruise",
      "Skip-the-line museum passes and Eiffel Tower tickets",
      "Macaron baking masterclass",
      "Public transport pass for Paris Metro"
    ],
    exclusions: [
      "Flights to Paris",
      "Airport transfers (available as add-on)",
      "Meals not specified"
    ],
    image: "/images/paris_france.png",
    gallery: [
      "/images/paris_france.png"
    ]
  },
  {
    id: "maldives-paradise",
    title: "Maldives Luxury Overwater Villa Resort",
    destination: "Ari Atoll, Maldives",
    category: "Leisure",
    price: 2999,
    duration: "7 Days / 6 Nights",
    durationDays: 7,
    rating: 4.98,
    reviewsCount: 65,
    description: "Escape to absolute paradise. Stay in a private overwater villa suspended over a turquoise lagoon. Swim with manta rays, relax with daily couples massage treatments, dine under the ocean at a glass restaurant, and soak in the endless horizon.",
    highlights: [
      "Stay in an overwater villa with direct lagoon access and private pool",
      "Scenic round-trip seaplane transfers from Malé Airport",
      "Sub-aquatic dining experience at a glass underwater restaurant",
      "Private sunset dolphin cruise with champagne"
    ],
    itinerary: [
      {
        day: 1,
        title: "Seaplane Flight to Resort & Villa Welcome",
        description: "Arrive in Malé and board your seaplane. Soar over coral atolls before landing at your private island resort. Check into your overwater villa and enjoy a complimentary bottle of champagne."
      },
      {
        day: 2,
        title: "Snorkeling Safari & Manta Ray Swim",
        description: "Join the marine biologist for a speedboat trip to nearby reefs. Snorkel alongside manta rays, sea turtles, and colorful reef fish. Afternoon free for beach relaxation."
      },
      {
        day: 3,
        title: "Overwater Spa Treatment & Yoga",
        description: "Start the day with a sunrise yoga session on the deck. Later, indulge in a 90-minute signature couples massage at the overwater spa with glass floor panels."
      },
      {
        day: 4,
        title: "Underwater Restaurant Lunch",
        description: "Dine five meters below the sea surface at the resort's glass dome restaurant. Watch sharks and fish swim around you while enjoying a 5-course gourmet tasting menu."
      },
      {
        day: 5,
        title: "Water Sports & Sunset Dolphin Cruise",
        description: "Try paddleboarding or windsurfing. In the evening, board a traditional wooden Dhoni for a sunset cruise, looking for schools of spinner dolphins leaping in the waves."
      },
      {
        day: 6,
        title: "Private Beach BBQ Dinner",
        description: "Enjoy a day at leisure. In the evening, experience a private torch-lit barbecue dinner directly on the sandy beach under the canopy of stars, with your personal chef."
      },
      {
        day: 7,
        title: "Seaplane Transfer to Malé",
        description: "Bid farewell to paradise. Take the seaplane back to Malé for your flight home, feeling completely rejuvenated."
      }
    ],
    inclusions: [
      "6 nights in a Luxury Overwater Pool Villa",
      "All-Inclusive meal package (Breakfast, Lunch, Dinner, Drinks)",
      "Round-trip seaplane transfers from Malé International Airport",
      "Sunset dolphin cruise and snorkeling gear rental",
      "One 90-minute spa treatment per adult"
    ],
    exclusions: [
      "International flights to Malé (MLE)",
      "Motorized water sports (jetski, flyboard)",
      "Souvenirs and laundry services"
    ],
    image: "/images/maldives.png",
    gallery: [
      "/images/maldives.png"
    ]
  }
];

export const categories = [
  { name: "Adventure", icon: "🏔️", count: 1, image: "/images/swiss_alps.png" },
  { name: "Culture", icon: "⛩️", count: 1, image: "/images/kyoto_japan.png" },
  { name: "Leisure", icon: "🏖️", count: 2, image: "/images/amalfi_coast.png" },
  { name: "Nature", icon: "🦁", count: 1, image: "/images/serengeti_safari.png" },
  { name: "History", icon: "🏛️", count: 1, image: "/images/paris_france.png" }
];
