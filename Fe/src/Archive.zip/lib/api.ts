// Next.js API Client to communicate with the Laravel Backend

export const getBaseUrl = () => {
  if (process.env.NEXT_PUBLIC_API_URL) {
    return process.env.NEXT_PUBLIC_API_URL;
  }
  if (typeof window !== 'undefined') {
    const hostname = window.location.hostname;
    if (hostname !== 'localhost' && hostname !== '127.0.0.1') {
      if (hostname.endsWith('logiclabz.in')) {
        return 'https://backdyna.logiclabz.in/api';
      }
      return `${window.location.origin}/api`;
    }
  }
  if (process.env.NODE_ENV === 'production') {
    return 'https://backdyna.logiclabz.in/api';
  }
  return 'http://127.0.0.1:8000/api';
};

export const BASE_URL = getBaseUrl();

export interface GalleryImage {
  url: string;
  section: 'banner' | 'gallery' | 'featured' | 'other';
}

export interface Destination {
  id: string;
  name: string;
  type: 'domestic' | 'international';
  parent_id: string | null;
  overview: string;
  how_to_reach: string | null;
  best_time_to_visit: string | null;
  banner_image: string | null;
  gallery: (string | GalleryImage)[] | null;
  top_attractions: Array<{
    name: string;
    fee: string;
    timings: string;
    highlights: string;
    note?: string;
  }> | null;
  show_packages: boolean;
  show_hotels: boolean;
  sub_destinations?: Destination[];
  hotels?: Hotel[];

  // SEO fields
  meta_title?: string | null;
  meta_description?: string | null;
  url_slug?: string | null;
  canonical_url?: string | null;

  // Location fields
  country?: string | null;
  state?: string | null;
  city?: string | null;

  // Related items mapping
  related_tours?: string[] | null;
}

export interface Room {
  id?: number;
  hotel_id?: string;
  type: string;
  size?: string | null;
  view?: string | null;
  bed_type?: string | null;
  breakfast?: string | null;
  occupancy?: string | null;
  image?: string | null;
  
  // Category enhancements
  description?: string | null;
  images?: string[] | null;
  amenities?: string[] | null;
  price?: number | null;
  video_url?: string | null;
}

export interface Facility {
  id: number;
  name: string;
  icon: string;
  description?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface Hotel {
  id: string;
  name: string;
  destination_id: string;
  short_description: string;
  about: string;
  location: string;
  distance_from_attractions: string | null;
  category: string;
  gallery: (string | GalleryImage)[] | null;
  facilities: Facility[] | null;
  featured: boolean;
  show_rooms: boolean;
  show_offer_label: boolean;
  show_price: boolean;
  price: number | null;
  offer_label: string | null;
  rooms?: Room[];
  destination?: Destination;

  // Hotel admin fields
  order_no?: number | null;
  status?: string;

  // SEO fields
  meta_title?: string | null;
  meta_description?: string | null;
  url_slug?: string | null;
  canonical_url?: string | null;
  og_title?: string | null;
  og_description?: string | null;

  // Location fields
  country?: string | null;
  state?: string | null;
  city?: string | null;

  // Terms info
  inclusions?: string | null;
  exclusions?: string | null;
  terms_conditions?: string | null;

  // Related items mapping
  related_hotels?: string[] | null;
  video_url?: string | null;
}

export interface Enquiry {
  id?: number;
  type: 'destination' | 'hotel';
  target_id: string;
  name: string;
  phone: string;
  email: string;
  num_people?: number;
  travel_date?: string;
  check_in?: string;
  check_out?: string;
  num_adults?: number;
  num_children?: number;
  children_ages?: string;
  message?: string;
  created_at?: string;
}

// Token helper methods
const TOKEN_KEY = 'dyna_admin_token';

const authHelper = {
  getToken: () => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem(TOKEN_KEY);
    }
    return null;
  },
  setToken: (token: string) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem(TOKEN_KEY, token);
    }
  },
  clearToken: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(TOKEN_KEY);
    }
  }
};

// Helper for fetch wrapper
async function apiFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${BASE_URL}${endpoint}`;
  
  // Attach token if present
  const token = authHelper.getToken();
  const headers = new Headers(options.headers);
  headers.set('Content-Type', 'application/json');
  headers.set('Accept', 'application/json');
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  try {
    const res = await fetch(url, {
      cache: 'no-store',
      ...options,
      headers
    });

    if (res.status === 401) {
      // Clear token and redirect if on client side
      authHelper.clearToken();
      if (typeof window !== 'undefined' && !window.location.pathname.includes('/login')) {
        window.location.href = '/admin/login';
      }
      throw new Error('Unauthorized');
    }

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`API error ${res.status}: ${errText}`);
    }

    return await res.json() as T;
  } catch (error) {
    console.error(`Fetch failed for endpoint: ${endpoint}`, error);
    throw error;
  }
}

export const api = {
  // Authentication operations
  login: async (email: string, password: string): Promise<{ token: string; user: { name: string; email: string } }> => {
    const res = await apiFetch<{ token: string; user: { name: string; email: string } }>('/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    if (res.token) {
      authHelper.setToken(res.token);
    }
    return res;
  },

  logout: async (): Promise<void> => {
    try {
      await apiFetch('/logout', {
        method: 'POST',
      });
    } catch (err) {
      console.error('Logout API failed', err);
    } finally {
      authHelper.clearToken();
    }
  },

  isAuthenticated: (): boolean => {
    return authHelper.getToken() !== null;
  },

  getToken: (): string | null => {
    return authHelper.getToken();
  },

  // Destination operations
  getDestinations: async (): Promise<Destination[]> => {
    try {
      return await apiFetch<Destination[]>('/destinations');
    } catch {
      return mockDestinations;
    }
  },

  getDestination: async (id: string): Promise<Destination> => {
    try {
      return await apiFetch<Destination>(`/destinations/${id}`);
    } catch {
      const found = mockDestinations.find(d => d.id === id);
      if (!found) throw new Error('Destination not found');
      return {
        ...found,
        sub_destinations: mockDestinations.filter(d => d.parent_id === id),
        hotels: mockHotels.filter(h => h.destination_id === id).sort((a, b) => {
          const orderA = a.order_no ?? Infinity;
          const orderB = b.order_no ?? Infinity;
          return orderA - orderB;
        }),
      };
    }
  },

  updateDestination: async (id: string, data: Partial<Destination>): Promise<{ message: string; destination: Destination }> => {
    return await apiFetch<{ message: string; destination: Destination }>(`/destinations/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  createDestination: async (data: Partial<Destination>): Promise<{ message: string; destination: Destination }> => {
    return await apiFetch<{ message: string; destination: Destination }>('/destinations', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  deleteDestination: async (id: string): Promise<{ message: string }> => {
    return await apiFetch<{ message: string }>(`/destinations/${id}`, {
      method: 'DELETE',
    });
  },

  // Hotel operations
  getHotels: async (params?: { destination_id?: string; category?: string; name?: string; featured?: boolean }): Promise<Hotel[]> => {
    try {
      let query = '';
      if (params) {
        const urlParams = new URLSearchParams();
        if (params.destination_id) urlParams.append('destination_id', params.destination_id);
        if (params.category) urlParams.append('category', params.category);
        if (params.name) urlParams.append('name', params.name);
        if (params.featured !== undefined) urlParams.append('featured', String(params.featured));
        query = `?${urlParams.toString()}`;
      }
      return await apiFetch<Hotel[]>(`/hotels${query}`);
    } catch {
      let filtered = [...mockHotels];
      if (params) {
        if (params.destination_id) filtered = filtered.filter(h => h.destination_id === params.destination_id);
        if (params.category) filtered = filtered.filter(h => h.category === params.category);
        if (params.name) filtered = filtered.filter(h => h.name.toLowerCase().includes(params.name!.toLowerCase()));
        if (params.featured !== undefined) filtered = filtered.filter(h => h.featured === params.featured);
      }
      filtered.sort((a, b) => {
        const orderA = a.order_no ?? Infinity;
        const orderB = b.order_no ?? Infinity;
        return orderA - orderB;
      });
      return filtered;
    }
  },

  getHotel: async (id: string): Promise<Hotel> => {
    try {
      return await apiFetch<Hotel>(`/hotels/${id}`);
    } catch {
      const found = mockHotels.find(h => h.id === id);
      if (!found) throw new Error('Hotel not found');
      return found;
    }
  },

  updateHotel: async (id: string, data: Partial<Hotel>): Promise<{ message: string; hotel: Hotel }> => {
    return await apiFetch<{ message: string; hotel: Hotel }>(`/hotels/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  createHotel: async (data: Partial<Hotel>): Promise<{ message: string; hotel: Hotel }> => {
    return await apiFetch<{ message: string; hotel: Hotel }>('/hotels', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  deleteHotel: async (id: string): Promise<{ message: string }> => {
    return await apiFetch<{ message: string }>(`/hotels/${id}`, {
      method: 'DELETE',
    });
  },

  getFacilities: async (): Promise<Facility[]> => {
    try {
      return await apiFetch<Facility[]>('/facilities');
    } catch {
      return mockFacilities;
    }
  },

  createFacility: async (data: Partial<Facility>): Promise<{ message: string; facility: Facility }> => {
    return await apiFetch<{ message: string; facility: Facility }>('/facilities', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  updateFacility: async (id: number, data: Partial<Facility>): Promise<{ message: string; facility: Facility }> => {
    return await apiFetch<{ message: string; facility: Facility }>(`/facilities/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  },

  deleteFacility: async (id: number): Promise<{ message: string }> => {
    return await apiFetch<{ message: string }>(`/facilities/${id}`, {
      method: 'DELETE',
    });
  },

  // Enquiry operations
  submitEnquiry: async (data: Enquiry): Promise<{ message: string; enquiry: Enquiry }> => {
    return await apiFetch<{ message: string; enquiry: Enquiry }>('/enquiries', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  },

  getEnquiries: async (): Promise<Enquiry[]> => {
    try {
      return await apiFetch<Enquiry[]>('/enquiries');
    } catch {
      return mockEnquiries;
    }
  }
};

// Fallback Mock Data for offline robustness
const mockDestinations: Destination[] = [
  {
    id: 'kerala',
    name: 'Kerala',
    type: 'domestic',
    parent_id: null,
    overview: 'God\'s Own Country is a tropical paradise with serene backwaters, hills, and greenery.',
    how_to_reach: 'Fly to Kochi or Thiruvananthapuram.',
    best_time_to_visit: 'September to March',
    banner_image: '/images/kerala_banner.png',
    gallery: [],
    top_attractions: [],
    show_packages: true,
    show_hotels: true,
  },
  {
    id: 'munnar',
    name: 'Munnar',
    type: 'domestic',
    parent_id: 'kerala',
    overview: 'Munnar is one of the most iconic hill stations in India, located in the Idukki district of Kerala. Nestled at an altitude of around 1,600 meters above sea level, Munnar is known for its endless stretches of tea plantations, mist-covered valleys, rolling hills, and cool mountain climate.',
    how_to_reach: 'Nearest Airport : Cochin International Airport ; 110 Kms away.',
    best_time_to_visit: 'September to February',
    banner_image: '/images/munnar_banner.png',
    gallery: [],
    top_attractions: [
      { name: 'Eravikulam National Park', fee: 'INR 125', timings: '07:30 AM – 04:00 PM', highlights: 'Nilgiri Tahr' }
    ],
    show_packages: true,
    show_hotels: true,
  },
  {
    id: 'thailand',
    name: 'Thailand',
    type: 'international',
    parent_id: null,
    overview: 'Thailand, famously known as "The Land of Smiles", is one of the most popular travel destinations in Southeast Asia.',
    how_to_reach: 'Fly to Bangkok (BKK) or Phuket (HKT).',
    best_time_to_visit: 'November to February',
    banner_image: '/images/thailand_banner.png',
    gallery: [],
    top_attractions: [],
    show_packages: true,
    show_hotels: true,
  }
];

const mockHotels: Hotel[] = [
  {
    id: 'blanket-hotel-spa-munnar',
    name: 'Blanket Hotel & Spa',
    destination_id: 'munnar',
    short_description: 'Blanket Hotel and Spa is a luxury 5-star resort set amidst the misty hills of Munnar.',
    about: 'Blanket Hotel and Spa is a luxury 5-star resort located in Pallivasal, Munnar.',
    location: 'Pallivasal, Munnar, Kerala',
    distance_from_attractions: 'Near Attukad Waterfalls',
    category: '5-Star',
    gallery: [
      '/images/blanket_hotel_mist.jpg',
      '/images/blanket_hotel_waterfall.jpg',
      '/images/blanket_hotel_room1.jpg',
      '/images/blanket_hotel_room2.jpg',
      '/images/blanket_hotel_pool.jpg'
    ],
    facilities: [
      { id: 1, name: 'Wifi', icon: 'wifi', description: 'High-speed wireless internet connection throughout the property' },
      { id: 2, name: 'Spa', icon: 'spa', description: 'Rejuvenating wellness spa offering body massages and therapies' },
      { id: 3, name: 'Pool', icon: 'pool', description: 'Scenic outdoor infinity swimming pool' },
      { id: 4, name: 'Breakfast', icon: 'breakfast', description: 'Delicious fresh hot breakfast options served daily' }
    ],
    featured: true,
    show_rooms: true,
    show_offer_label: true,
    show_price: true,
    price: 180,
    offer_label: 'Special 15% Off',
    order_no: 1,
    rooms: [
      { id: 1, hotel_id: 'blanket-hotel-spa-munnar', type: 'Blanket Camelia', size: '320 sq.ft', view: 'Garden View', bed_type: 'Queen Bed', breakfast: 'Included', occupancy: '2 Adults', image: '/images/blanket_camelia.jpg' }
    ]
  }
];

const mockFacilities: Facility[] = [
  { id: 1, name: 'Breakfast', icon: 'breakfast', description: 'Delicious fresh hot breakfast options served daily' },
  { id: 2, name: 'Wifi', icon: 'wifi', description: 'High-speed wireless internet connection throughout the property' },
  { id: 3, name: 'Gym', icon: 'gym', description: 'Fully equipped modern fitness center' },
  { id: 4, name: 'Spa', icon: 'spa', description: 'Rejuvenating wellness spa offering body massages and therapies' },
  { id: 5, name: 'Pool', icon: 'pool', description: 'Scenic outdoor infinity swimming pool' },
  { id: 6, name: 'Restaurant', icon: 'restaurant', description: 'Fine-dining restaurant serving local and international cuisines' },
  { id: 7, name: 'Bar', icon: 'bar', description: 'Elegant lounge bar with premium drinks and cocktails' },
  { id: 8, name: 'Indoor games', icon: 'indoor games', description: 'Recreation room with board games, table tennis, and billiards' },
  { id: 9, name: 'Activity', icon: 'activity', description: 'Adventure activities, nature treks, and cycling tours' },
  { id: 10, name: 'Airport Transport', icon: 'airport transport', description: 'Complimentary airport shuttle and local transit arrangements' },
  { id: 11, name: 'sight seeing', icon: 'sight seeing', description: 'Guided local sightseeing tours and scenic viewpoint excursions' }
];

const mockEnquiries: Enquiry[] = [];
