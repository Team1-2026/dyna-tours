import type { Metadata } from 'next';
import { Outfit, Playfair_Display } from 'next/font/google';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import './globals.css';

// Premium Sans Font for Body
const outfit = Outfit({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-outfit',
  weight: ['300', '400', '500', '600', '700', '800'],
});

// Premium Serif Font for Headings
const playfair = Playfair_Display({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-playfair',
  weight: ['400', '600', '700', '800', '900'],
});

export const metadata: Metadata = {
  title: 'Dyna Tours | Luxury Tours & Curated Travel Experiences',
  description: 'Embark on unforgettable journeys across the globe with Dyna Tours. We design bespoke and premium travel packages featuring Zermatt, Kyoto, Amalfi Coast, and Serengeti.',
  keywords: ['travel agency', 'luxury tours', 'vacation packages', 'swiss alps tour', 'kyoto temple tour', 'amalfi coast travel', 'serengeti safari'],
  authors: [{ name: 'Dyna Tours Team' }],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${outfit.variable} ${playfair.variable}`} suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </head>
      <body style={{ 
        display: 'flex', 
        flexDirection: 'column', 
        minHeight: '100vh',
        fontFamily: 'var(--font-outfit), sans-serif',
        // Define Font Variables mapping
        ['--font-sans' as any]: 'var(--font-outfit), sans-serif',
        ['--font-headings' as any]: 'var(--font-playfair), serif'
      }}>
        <Navbar />
        <main style={{ flex: '1 0 auto', paddingTop: '80px' }}>
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
